package comp352.datastructures.huffman;

// This is just a super basic Node function, nothing special

public class Node {

    public Node left, right;
    public int frequency;
    char key;
    public String path = "";

    public Node(char key, int frequency) {
        this.frequency = frequency;
        this.key = key;
    }
}
