package comp352.datastructures.huffman;

public class NodeQueue {

    private Node[] content;

    /**
     * Constructor which creates an empty array
     */
    public NodeQueue() {
        this.content = new Node[0];
    }

    /**
     *
     * @return the size of the queue
     */
    public int size() {
        return this.content.length;
    }

    /**
     * Function used to check if a node (or a node containing a char is already in the queue or not
     * @param key the char to look for in the queue of Nodes
     * @return the index of the node if it is present, -1 otherwise
     */
    private int contains(char key) {
        for (int i = 0; i < content.length; i++) {
            if (key == content[i].key) return i;
        }
        return -1;
    }

    /**
     * This function adds a node to the list, but first it checks if the node is already in the list, and if yes, it will just
     * increment the frequency. It calls the contains function, and then checks if the returned value is positive or -1.
     * If it is not in the list, then it will add one by creating a new array of length current+1, copying, etc.
     * @param node the node to add in the queue
     * @return true if the node was successfully added, false otherwise
     */
    public boolean add(Node node) {
        int index = contains(node.key); // Checks if the node is already in the list

        if (index >= 0) { // The node is in the list, we can just increment the frequency
            content[index].frequency++;
            return true;
        }

        // The node is not in the list, we add at the end (my exercise is asking to sort the nodes as they appear in the haiku)
        Node[] newContent = new Node[content.length + 1];
        System.arraycopy(content, 0, newContent, 0, content.length);
        newContent[content.length] = node;
        content = newContent;

        return true;
    }

    /**
     * This function is used when creating the tree from main, but it basically returns the FIRST minimum it finds
     * (it returns the minimum, and if there are duplicates, it returns the first occurrence it found). It also removes
     * that node from the list
     * @return the minimum in the list
     */
    public Node pop() {
        Node min = this.content[0]; // "current" min
        int index = 0;

        for (int i = 1; i < this.content.length; i++) {
            if (this.content[i].frequency < min.frequency) {
                min = this.content[i];
                index = i;
            }
        }

        // Removing the node from the list using the int we saved as index
        Node[] newContent = new Node[this.content.length - 1];
        if (newContent.length > 0) {
            System.arraycopy(this.content, 0, newContent, 0, index);
            System.arraycopy(this.content, index + 1, newContent, index, newContent.length - index);
        }

        this.content = newContent;
        return min;
    }

    /**
     * This function is really just adding the node at the end of the list, no questions asked
     * It is used for creating the tree again
     * @param node the node to add
     */
    public void offerLast(Node node) {
        Node[] newContent = new Node[this.content.length + 1];
        System.arraycopy(this.content, 0, newContent, 0, this.content.length);
        newContent[newContent.length - 1] = node;
        this.content = newContent;
    }

    /**
     * Fancy debugging function to print the content of the list
     */
    public void print() {
        for (Node node : content) {
            System.out.print(node.key + " " + node.frequency + "  | ");
        }
        System.out.println();
    }

    /**
     * This function uses Insertion sort to sort the values in the queue to make it ready for tree creation
     * Insertion sort is preferred for its easiness to implement AND FOR ITS STABILITY
     */
    public void insertionSort() {
        for (int i = 1; i < this.content.length; i++) {
            Node keyNode = this.content[i];
            int j = i - 1;

            while (j >= 0 && this.content[j].frequency < keyNode.frequency) {
                this.content[j + 1] = this.content[j];
                j--;
            }

            this.content[j + 1] = keyNode;
        }
    }

    /**
     * Ah yes, the thing that took me wayyy too long to understand
     * Basically, my OS/laptop does not recognize the '\r' character, so I have to add a manual "placeholder" right before the '\n'
     * character, and this function is where I do it
     *
     * Not having this function would mess up the tree since we were missing a node etc.
     */
    public void specialAdd() {
        Node node = new Node('/', 2);
        Node[] newContent = new Node[this.content.length + 1];
        for (int i = 0, j = 0; i < newContent.length; i++, j++) {
            if (content[j].key == '\n') {
                newContent[i] = node;
                newContent[i + 1] = content[j];
                i++;
            } else {
                newContent[i] = content[j];
            }
        }
        this.content = newContent;
    }
}
