// Constance Prevot 40241987
// COMP-352 Assignment 3

// THEORY QUESTION 1
// What is the purpose of using a priority queue in Huffman coding, and how does it help to generate an optimal code?

// In theory, using a priority queue to construct a Huffman tree allows us to access the node we want in just O(1), since
// the nodes are sorted efficiently (in my case, in decreasing frequency and most recent last).
// When we create an internal node and insert it back into the queue, we put it at the end so that it is close to nodes with similar frequencies,
// This makes the whole process optimal since the node will be reused soon (so less searching throughout the tree overall).


// THEORY QUESTION 2
// How does the length of a Huffman code relate to the frequency of the corresponding symbol, and why is this useful for data compression?

// The length of a Huffman code and the frequency of the corresponding character are inversely proportional to each other.
// This is because we construct the tree starting with the least frequent characters of the priority queue, creating and inserting
// more internal nodes for those than for the most frequent characters.
// This process is smart when it comes to data compression since the most used characters will have a very short path, so
// it takes advantage of the statistics of the first data input, achieving a very efficient and compact data compression.


// THEORY QUESTION 3
// What is the time complexity of building a Huffman code, and how can you optimize it?

// The time complexity of building a huffman tree is


package comp352.datastructures.huffman;

import java.util.Scanner;
import java.io.*;

public class HCDriver {

    public static NodeQueue queue;
    public static Node root;
    public static String input;

    public static void main(String[] args) {

        String task = args[1];
        String path = args[0];

        // For debugging, manual entry
//        String task = "decode";
//        String task = "encode";
//        String path = "/Users/constance/IdeaProjects/Assignment 4/src/haiku1.txt";

        // Scanner user input, as asked
        Scanner scanner = new Scanner(System.in);
        input = scanner.nextLine().toLowerCase();

        String result = haikuFinder(path);
//        System.out.println(result);

        queue = new NodeQueue(); // Creates the Queue

        for (int i = 0; i < result.length(); i++) // Fills up the queue char by char
            queue.add(new Node(result.charAt(i), 1));

        queue.specialAdd(); // Need this for '\r', see function javadoc for more details
        queue.insertionSort(); // Sorts the queue, ready for tree creation after
//        queue.print(); // Debugging

        root = buildTree(); // Builds the tree
//        preorder(root); // Debugging

        // Prints the result depending on input
        System.out.println(task.equalsIgnoreCase("encode") ? encode(root) : decode(root));

    }

    /**
     * Function that traverse the tree using pre-order and prints stuff accordingly.
     * The first commented line just prints the key (char) of every node
     * The second commented line just prints the key of leaves (basically if the key is NOT \0
     * The third line prints, for leaves only, the key and the path to that key -> very cool for debugging
     * @param node the root of the tree
     */
    public static void preorder(Node node) {
        if (node == null) return;
//        System.out.print("|" + node.key + "|  ");
//        if (node.key != '\0') System.out.print("|" + node.key + "|  ");
//        if (node.key != '\0') System.out.print("|" + node.key + " : " + node.path + '|');
        preorder(node.left);
        preorder(node.right);
    }

    /**
     * This function encodes the input, using a for loop (for each character) and brute-force to find the right leaf
     * @param node the root of the tree
     * @return the encoded input
     */
    public static String encode(Node node) {
//        map(node, ""); // very cool function, I'm sad I didn't get to use it in the end
        String result = "";
        for (int i = 0; i < input.length(); i++) {
            result += findPath(node, input.charAt(i));
        }
        return result;
    }

    /**
     * This function decodes the input, using a for-loop for every character, and basically while it is not a leaf (its key char is not \0)
     *      it will travel around the tree
     * @param root the root of the tree
     * @return the decoded message
     */
    public static String decode(Node root) {
        String result = "";
        Node node = root;

        for (int i = 0; i < input.length(); i++) { // For each character in the input
            if (node.key != '\0') { // if node is a leaf (does not have \0 as char key)
                result += node.key;
                node = root;
            }
            if (input.charAt(i) == '0') node = node.left; // if it is not a leaf, then go left (cause charAt is 0)
            else if (input.charAt(i) == '1') node = node.right; // if it is not a leaf, then go left (cause charAt is 0)
        }
        if (node.key != '\0') result += node.key; // does it for the last char as you know, edge cases
        return result;
    }

    /**
     * This function just takes care of reading the file input and stored it in a String
     * @param path the path to the file
     * @return a String version of the file
     */
    public static String haikuFinder(String path) {
        String result = "";
        try {
            Scanner scanner = new Scanner(new File(path));
            while (scanner.hasNextLine()) result += scanner.nextLine() + "\n";
            result = result.trim();
        } catch (Exception e) {
            System.out.println("Check ton path patate");
        }
        return result.toLowerCase();
    }

    /**
     * AHHHHH my favorite function
     * It builds the tree from the Priority Queue
     * It's just so cool
     * @return the root of the tree
     */
    public static Node buildTree() {
        while (queue.size() > 1) { // When the Priority Queue is 1, that means we only have the root left basically
            Node leftNode = queue.pop();
            Node rightNode = queue.pop();

            Node parent = new Node('\0', leftNode.frequency + rightNode.frequency);
            parent.left = leftNode;
            parent.right = rightNode;

            queue.offerLast(parent);
        }

        return queue.pop();
    }

    /**
     * Actually I lied, this is my favorite function, I'm sad I didn't use it in the end
     * It would just fill up the path for every leaf, but using recursion mind you
     * @param node the root of the tree
     * @param path the current path of the node, used for recursion purposes
     */
    public static void map(Node node, String path) {
        if (node == null) return;
        if (node.key != '\0') {
            node.path = path;
            return;
        }
        map(node.left, path + "0");
        map(node.right, path + "1");
    }

    /**
     * The actual funtion I ended up using for encoding an input, it's kind of not efficient at all but no time to fix
     * It's just brute-forcing it until it finds the node
     * @param root the root of the tree
     * @param key the char to find in the tree
     * @return the path to the node in terms of 0's and 1's
     */
    public static String findPath(Node root, char key) {
        if (root == null) {
            return null; // Node not found
        }
        if (root.key == key) {
            return root.path; // Found the node with the key
        }
        String leftPath = findPath(root.left, key);
        if (leftPath != null) {
            return "0" + leftPath; // Key found in the left subtree
        }
        String rightPath = findPath(root.right, key);
        if (rightPath != null) {
            return "1" + rightPath; // Key found in the right subtree
        }
        return null; // Key not found
    }
}
