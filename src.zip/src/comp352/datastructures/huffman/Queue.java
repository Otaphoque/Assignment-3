package comp352.datastructures.huffman;

public class Queue {

    private char[] keys;
    private int[] values;

    public Queue() {
        this.keys = new char[0];
        this.values = new int[0];
    }

    public int size() {
        return this.keys.length;
    }

    private int contains(char key) {
        for (int i = 0; i < keys.length; i++) {
            if (key == keys[i]) return i;
        }
        return -1;
    }

    public boolean add(char key) {
        int index = contains(key);
        if (index >= 0) {
            values[index]++;
            return true;
        }

        char[] newKeys = new char[keys.length + 1];
        int[] newValues = new int[values.length + 1];
        for (int i = 0; i < keys.length; i++) {
            newKeys[i] = keys[i];
            newValues[i] = values[i];
        }
        newKeys[keys.length] = key;
        newValues[values.length] = 1;
        keys = newKeys;
        values = newValues;

        return true;
    }

    public Node pop() {
        return null;
    }

    public void print() {
        for (int i = 0; i < keys.length; i++) {
            System.out.println(keys[i] + " " + values[i]);
        }
    }

    public void insertionSort() {
        int n = this.values.length;

        for (int i = 1; i < n; ++i) {
            int key1 = this.values[i];
            char key2 = this.keys[i];
            int j = i - 1;

            while (j >= 0 && this.values[j] < key1) {
                this.values[j + 1] = this.values[j];
                this.keys[j + 1] = this.keys[j];
                j = j - 1;
            }

            this.values[j + 1] = key1;
            this.keys[j + 1] = key2;
        }
    }
}
